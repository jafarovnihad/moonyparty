// 1. INITIALIZE: Load everything from last time
chrome.storage.local.get(['roomName', 'userName', 'userColor'], (res) => {
  if (res.roomName) document.getElementById('roomInput').value = res.roomName;
  if (res.userName) document.getElementById('nameInput').value = res.userName;
  if (res.userColor) document.getElementById('colorInput').value = res.userColor;
  
  if (res.roomName) {
    document.getElementById('status').innerText = "Last used: " + res.roomName;
  }
});

// 2. AUTO-SAVE: Save data as you type so it's never lost
const saveCurrentData = () => {
  const roomName = document.getElementById('roomInput').value.trim();
  const userName = document.getElementById('nameInput').value.trim();
  const userColor = document.getElementById('colorInput').value;
  chrome.storage.local.set({ roomName, userName, userColor });
};

document.getElementById('roomInput').oninput = saveCurrentData;
document.getElementById('nameInput').oninput = saveCurrentData;
document.getElementById('colorInput').oninput = saveCurrentData;

// 3. JOIN LOGIC
document.getElementById('joinBtn').onclick = () => {
  const roomName = document.getElementById('roomInput').value.trim();
  const userName = document.getElementById('nameInput').value.trim() || "Guest";
  const userColor = document.getElementById('colorInput').value;

  if (!roomName) {
    document.getElementById('status').innerText = "Error: Enter a Room!";
    return;
  }

  // Final save on click just to be sure
  chrome.storage.local.set({ roomName, userName, userColor }, () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]) return;

      chrome.tabs.sendMessage(tabs[0].id, { 
        action: "join_room", 
        room: roomName, 
        user: userName, 
        color: userColor 
      }, (response) => {
        if (chrome.runtime.lastError) {
          document.getElementById('status').innerText = "Error: Refresh the page!";
        } else {
          document.getElementById('status').innerText = "Joined: " + roomName;
        }
      });
    });
  });
};

// 4. FORCE SYNC
document.getElementById('syncBtn').onclick = () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, { action: "force_sync" });
    }
  });
};