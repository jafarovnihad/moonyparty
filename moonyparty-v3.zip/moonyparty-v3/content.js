const SERVER_URL = "https://my-party-server-060k.onrender.com"; 
let socket = io(SERVER_URL, { reconnection: true });
let video = null;
let isRemoteChange = false;
let myUsername = "Guest";
let myColor = "#54b3ff";
let lastUrl = location.href;
let isJoined = false; 

// --- UI Injection ---
const chatContainer = document.createElement('div');
chatContainer.id = 'party-chat-container';
chatContainer.style.display = 'none'; 
chatContainer.innerHTML = `
  <div id="chat-header">
    <span>Party Chat</span>
    <div class="counter-wrapper">
        <span id="party-counter">0 online</span>
        <div id="user-list-tooltip">No one else here</div>
    </div>
  </div>
  <div id="chat-messages"></div>
  <div id="chat-input-area">
    <input type="text" id="chat-input" placeholder="Say something...">
  </div>
`;
document.body.appendChild(chatContainer);

const toggleBtn = document.createElement('button');
toggleBtn.id = 'chat-toggle-btn';
toggleBtn.innerText = '💬';
toggleBtn.style.display = 'none'; 
document.body.appendChild(toggleBtn);

// --- Style Definitions ---
const style = document.createElement('style');
style.textContent = `
  body { transition: margin-right 0.3s ease; }
  .body-pushed { margin-right: 300px !important; }
  #party-chat-container {
    position: fixed; right: 0; top: 0; bottom: 0;
    width: 300px; background: #000; color: #fff;
    z-index: 9999999; display: flex; flex-direction: column;
    border-left: 1px solid #333; font-family: sans-serif;
  }
  #chat-toggle-btn {
    position: fixed; right: 20px; bottom: 20px;
    z-index: 10000000; width: 50px; height: 50px;
    border-radius: 50%; background: #e50914; color: white;
    border: none; cursor: pointer; font-size: 20px;
  }
  #chat-header { 
    padding: 15px; background: #e50914; font-weight: bold; 
    display: flex; justify-content: space-between; align-items: center; 
  }
  .counter-wrapper { position: relative; cursor: pointer; }
  #party-counter { font-size: 11px; background: rgba(0,0,0,0.3); padding: 2px 8px; border-radius: 10px; }
  #user-list-tooltip {
    position: absolute; right: 0; top: 25px; background: #222;
    border: 1px solid #444; padding: 10px; border-radius: 5px;
    width: 120px; display: none; font-size: 11px; font-weight: normal;
    z-index: 10000001; box-shadow: 0 4px 10px rgba(0,0,0,0.5);
  }
  .counter-wrapper:hover #user-list-tooltip { display: block; }
  #chat-messages { flex: 1; overflow-y: auto; padding: 10px; display: flex; flex-direction: column; gap: 2px; }
  #chat-input-area { padding: 10px; border-top: 1px solid #333; background: #111; }
  #chat-input { width: 100%; padding: 10px; background: #222; color: #fff; border: none; border-radius: 4px; }
  .chat-msg { font-size: 13px; line-height: 1.2; }
  .sys-msg { font-size: 11px; color: #888; font-style: italic; text-align: center; margin: 2px 0; }
  .video-shrunk video { max-width: calc(100vw - 300px) !important; height: auto !important; }
`;
document.head.appendChild(style);

// --- UI Logic ---
toggleBtn.onclick = () => {
  const isHidden = chatContainer.style.display === 'none';
  chatContainer.style.display = isHidden ? 'flex' : 'none';
  document.body.classList.toggle('body-pushed', isHidden);
  if (video) isHidden ? video.parentElement.classList.add('video-shrunk') : video.parentElement.classList.remove('video-shrunk');
};

// --- Initialization ---
chrome.storage.local.get(['roomName', 'userName', 'userColor'], (res) => {
  if (res.userName && res.roomName) {
    myUsername = res.userName;
    myColor = res.userColor;
    socket.emit("join", { room: res.roomName, user: myUsername });
  }
});

// --- Socket Communication ---
socket.on('room_stats', (data) => {
  document.getElementById('party-counter').innerText = `${data.count} online`;
  document.getElementById('user-list-tooltip').innerHTML = `<b>In Room:</b><br>${data.users.join('<br>')}`;
});

function addChatMessage(data) {
  if (!isJoined) return;
  const msgList = document.getElementById('chat-messages');
  const div = document.createElement('div');
  if (data.isSystem || !data.user) {
    div.className = 'sys-msg'; div.innerText = data.text;
  } else {
    div.className = 'chat-msg';
    div.innerHTML = `<b style="color: ${data.color || '#54b3ff'}">${data.user}:</b> ${data.text}`;
  }
  msgList.appendChild(div);
  msgList.scrollTop = msgList.scrollHeight;
}

function logSyncAction(user, type, time) {
  if (!isJoined) return;
  const timeStr = new Date(time * 1000).toISOString().substr(14, 5);
  let actionText = type === 'play' ? "played at" : (type === 'pause' ? "paused at" : "jumped to");
  addChatMessage({ text: `${user} ${actionText} ${timeStr}`, isSystem: true });
}

// --- Video & Events ---
setInterval(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href;
    socket.emit("change_url", { url: location.href, user: myUsername });
    if (isJoined) addChatMessage({ text: `${myUsername} started next episode`, isSystem: true });
  }
  const currentVideo = document.querySelector('video');
  if (currentVideo && currentVideo !== video) {
    video = currentVideo;
    setupVideoListeners();
  }
}, 2000);

function setupVideoListeners() {
  video.onplay = () => { if (!isRemoteChange) { socket.emit("video_event", { type: "play", time: video.currentTime, user: myUsername }); logSyncAction(myUsername, "play", video.currentTime); } };
  video.onpause = () => { if (!isRemoteChange) setTimeout(() => { if (!isRemoteChange) { socket.emit("video_event", { type: "pause", time: video.currentTime, user: myUsername }); logSyncAction(myUsername, "pause", video.currentTime); } }, 200); };
  video.onseeking = () => { if (!isRemoteChange) { socket.emit("video_event", { type: "seek", time: video.currentTime, user: myUsername }); logSyncAction(myUsername, "seek", video.currentTime); } };

  socket.on("sync_video", (data) => {
    isRemoteChange = true;
    if (Math.abs(video.currentTime - data.time) > 1.5) video.currentTime = data.time;
    data.type === "play" ? video.play() : video.pause();
    logSyncAction(data.user, data.type, data.time);
    setTimeout(() => { isRemoteChange = false; }, 600);
  });

  socket.on("navigate_to", (data) => {
    addChatMessage({ text: `${data.user} started next episode`, isSystem: true });
    setTimeout(() => { location.href = data.url; }, 2000);
  });
}

// --- Chat Logic ---
document.getElementById('chat-input').addEventListener('keypress', (e) => {
  if (e.key === 'Enter' && e.target.value.trim() !== "") {
    socket.emit('send_message', { user: myUsername, text: e.target.value, color: myColor });
    e.target.value = "";
  }
});
socket.on('receive_message', (data) => addChatMessage(data));

// --- Popup Commands ---
chrome.runtime.onMessage.addListener((request) => {
  if (request.action === "join_room") {
    myUsername = request.user;
    myColor = request.color;
    socket.emit("join", { room: request.room, user: myUsername });
    isJoined = true;
    toggleBtn.style.display = 'block';
  }
});