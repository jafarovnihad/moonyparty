const SERVER_URL = "https://my-party-server-060k.onrender.com"; 
let socket = io(SERVER_URL, { reconnection: true });
let video = null;
let isRemoteChange = false;
let myUsername = "Guest";
let myColor = "#54b3ff";
let lastUrl = location.href;
let isJoined = false; 

const hostname = window.location.hostname;
const isNetflix = hostname.includes('netflix.com');
const isYouTube = hostname.includes('youtube.com');
const isHBO = hostname.includes('hbomax.com') || hostname.includes('max.com');

const chatContainer = document.createElement('div');
chatContainer.id = 'party-chat-container';
chatContainer.style.display = 'none'; 
chatContainer.innerHTML = `
  <div id="chat-header">
    <span>Party Chat</span>
    <div class="counter-wrapper">
        <span id="party-counter">0 online</span>
        <div id="user-list-tooltip">No one else here</div>
    </div>
  </div>
  <div id="chat-messages"></div>
  <div id="chat-input-area">
    <input type="text" id="chat-input" placeholder="Say something...">
  </div>
`;
document.body.appendChild(chatContainer);

const toggleBtn = document.createElement('button');
toggleBtn.id = 'chat-toggle-btn';
toggleBtn.innerText = '💬';
toggleBtn.style.display = 'none'; 
document.body.appendChild(toggleBtn);

const style = document.createElement('style');
style.textContent = `
  #party-chat-container {
    position: fixed; right: 0; top: 0; bottom: 0;
    width: 300px; background: rgba(0, 0, 0, 0.95); color: #fff;
    z-index: 9999999; display: flex; flex-direction: column;
    border-left: 2px solid #333; font-family: sans-serif;
    box-shadow: -5px 0 20px rgba(0, 0, 0, 0.5);
  }
  #chat-toggle-btn {
    position: fixed; right: 20px; bottom: 20px;
    z-index: 10000000; width: 50px; height: 50px;
    border-radius: 50%; background: #e50914; color: white;
    border: none; cursor: pointer; font-size: 20px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3); transition: transform 0.2s;
  }
  #chat-toggle-btn:hover { transform: scale(1.05); }
  #chat-header { padding: 15px; background: #e50914; font-weight: bold; display: flex; justify-content: space-between; align-items: center; }
  .counter-wrapper { position: relative; cursor: pointer; }
  #party-counter { font-size: 11px; background: rgba(0,0,0,0.3); padding: 2px 8px; border-radius: 10px; }
  #user-list-tooltip {
    position: absolute; right: 0; top: 25px; background: #222;
    border: 1px solid #444; padding: 10px; border-radius: 5px;
    width: 120px; display: none; font-size: 11px; font-weight: normal;
    z-index: 10000001; box-shadow: 0 4px 10px rgba(0,0,0,0.5);
  }
  .counter-wrapper:hover #user-list-tooltip { display: block; }
  #chat-messages { flex: 1; overflow-y: auto; padding: 10px; display: flex; flex-direction: column; gap: 2px; }
  #chat-input-area { padding: 10px; border-top: 1px solid #333; background: #111; }
  #chat-input { width: 100%; padding: 10px; background: #222; color: #fff; border: none; border-radius: 4px; }
  .chat-msg { font-size: 13px; line-height: 1.2; }
  .sys-msg { font-size: 11px; color: #888; font-style: italic; text-align: center; margin: 2px 0; }
  body.yt-chat-open #secondary { display: none !important; }
  body.yt-chat-open #primary { margin-right: 300px !important; }
`;
document.head.appendChild(style);

function resizePlayer(enable) {
  if (isYouTube) {
    document.body.classList.toggle('yt-chat-open', enable);
    return;
  }
  
  let targetElement = null;
  if (isNetflix) {
    targetElement = document.querySelector('.watch-video') || document.querySelector('.NFPlayer');
  } else if (isHBO) {
    targetElement = document.querySelector('[data-testid="playerContainer"]');
  } else {
    const videoEl = document.querySelector('video');
    if (videoEl) targetElement = videoEl.parentElement;
  }
  
  if (targetElement) {
    targetElement.style.width = enable ? 'calc(100% - 300px)' : '';
    targetElement.style.left = enable ? '0px' : '';
  }
}

toggleBtn.onclick = () => {
  const isHidden = chatContainer.style.display === 'none';
  chatContainer.style.display = isHidden ? 'flex' : 'none';
  resizePlayer(isHidden);
};

chrome.storage.local.get(['roomName', 'userName', 'userColor'], (res) => {
  if (res.userName && res.roomName) {
    myUsername = res.userName;
    myColor = res.userColor;
    
    if (sessionStorage.getItem('shouldRejoin') === 'true') {
      sessionStorage.removeItem('shouldRejoin');
      socket.emit("join", { room: res.roomName, user: myUsername, activate: true });
      isJoined = true;
      toggleBtn.style.display = 'block';
      
      const savedHistory = sessionStorage.getItem('chatHistory');
      if (savedHistory) {
        setTimeout(() => {
          document.getElementById('chat-messages').innerHTML = savedHistory;
          sessionStorage.removeItem('chatHistory');
        }, 100);
      }
      
      if (sessionStorage.getItem('chatWasOpen') === 'true') {
        setTimeout(() => {
          chatContainer.style.display = 'flex';
          resizePlayer(true);
          sessionStorage.removeItem('chatWasOpen');
        }, 100);
      }
      
      if (sessionStorage.getItem('needsSync') === 'true') {
        sessionStorage.removeItem('needsSync');
        setTimeout(() => socket.emit("request_sync", { room: res.roomName }), 3000);
      }
    } else {
      socket.emit("join", { room: res.roomName, user: myUsername });
    }
  }
});

socket.on('room_stats', (data) => {
  document.getElementById('party-counter').innerText = `${data.count} online`;
  document.getElementById('user-list-tooltip').innerHTML = `<b>In Room:</b><br>${data.users.join('<br>')}`;
});

function addChatMessage(data) {
  if (!isJoined) return;
  const msgList = document.getElementById('chat-messages');
  const div = document.createElement('div');
  if (data.isSystem || !data.user) {
    div.className = 'sys-msg'; div.innerText = data.text;
  } else {
    div.className = 'chat-msg';
    div.innerHTML = `<b style="color: ${data.color || '#54b3ff'}">${data.user}:</b> ${data.text}`;
  }
  msgList.appendChild(div);
  msgList.scrollTop = msgList.scrollHeight;
}

function logSyncAction(user, type, time) {
  if (!isJoined) return;
  const timeStr = new Date(time * 1000).toISOString().substr(14, 5);
  let actionText = type === 'play' ? "played at" : (type === 'pause' ? "paused at" : "jumped to");
  addChatMessage({ text: `${user} ${actionText} ${timeStr}`, isSystem: true });
}

// Use MutationObserver instead of setInterval for URL changes
const urlObserver = new MutationObserver(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href;
    socket.emit("change_url", { url: location.href, user: myUsername });
    if (isJoined) addChatMessage({ text: `${myUsername} started next episode`, isSystem: true });
  }
});

// Start observing URL changes
urlObserver.observe(document, { subtree: true, childList: true });

// Check for video element every 2 seconds (still needed)
setInterval(() => {
  const currentVideo = document.querySelector('video');
  if (currentVideo && currentVideo !== video) {
    video = currentVideo;
    setupVideoListeners();
  }
}, 2000);

function setupVideoListeners() {
  video.onplay = () => { if (!isRemoteChange) { socket.emit("video_event", { type: "play", time: video.currentTime, user: myUsername }); logSyncAction(myUsername, "play", video.currentTime); } };
  video.onpause = () => { if (!isRemoteChange) setTimeout(() => { if (!isRemoteChange) { socket.emit("video_event", { type: "pause", time: video.currentTime, user: myUsername }); logSyncAction(myUsername, "pause", video.currentTime); } }, 200); };
  video.onseeking = () => { if (!isRemoteChange) { socket.emit("video_event", { type: "seek", time: video.currentTime, user: myUsername }); logSyncAction(myUsername, "seek", video.currentTime); } };

  socket.on("sync_video", (data) => {
    if (!isJoined) return;
    isRemoteChange = true;
    if (Math.abs(video.currentTime - data.time) > 1.5) video.currentTime = data.time;
    data.type === "play" ? video.play() : video.pause();
    logSyncAction(data.user, data.type, data.time);
    setTimeout(() => { isRemoteChange = false; }, 600);
  });

  socket.on("navigate_to", (data) => {
    if (!isJoined) return;
    addChatMessage({ text: `${data.user} started next episode`, isSystem: true });
    
    const chatMessages = document.getElementById('chat-messages');
    if (chatMessages) {
      const messages = Array.from(chatMessages.children).slice(-200);
      sessionStorage.setItem('chatHistory', messages.map(m => m.outerHTML).join(''));
    }
    sessionStorage.setItem('shouldRejoin', 'true');
    sessionStorage.setItem('chatWasOpen', chatContainer.style.display === 'flex' ? 'true' : 'false');
    sessionStorage.setItem('needsSync', 'true');
    
    setTimeout(() => { location.href = data.url; }, 2000);
  });
}

document.getElementById('chat-input').addEventListener('keypress', (e) => {
  if (e.key === 'Enter' && e.target.value.trim() !== "") {
    socket.emit('send_message', { user: myUsername, text: e.target.value, color: myColor });
    e.target.value = "";
  }
});

socket.on('receive_message', (data) => addChatMessage(data));

socket.on('provide_sync', (data) => {
  if (video && isJoined) {
    socket.emit('sync_response', {
      requesterId: data.requester,
      state: { type: video.paused ? 'pause' : 'play', time: video.currentTime, user: myUsername }
    });
  }
});

chrome.runtime.onMessage.addListener((request) => {
  if (request.action === "join_room") {
    myUsername = request.user;
    myColor = request.color;
    socket.emit("join", { room: request.room, user: myUsername, activate: true });
    isJoined = true;
    toggleBtn.style.display = 'block';
  }
  
  // Force sync handler
  if (request.action === "force_sync" && video && isJoined) {
    socket.emit("video_event", { 
      type: video.paused ? 'pause' : 'play', 
      time: video.currentTime, 
      user: myUsername 
    });
  }
});