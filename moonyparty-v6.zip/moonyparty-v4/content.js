const SERVER_URL = "https://my-party-server-060k.onrender.com"; 
let socket = io(SERVER_URL, { reconnection: true });
let video = null;
let isRemoteChange = false;
let myUsername = "Guest";
let myColor = "#54b3ff";
let myRoom = null;
let lastUrl = location.href;
let isJoined = false; 

const hostname = window.location.hostname;
const isNetflix = hostname.includes('netflix.com');
const isYouTube = hostname.includes('youtube.com');
const isHBO = hostname.includes('hbomax.com') || hostname.includes('max.com');

const GIPHY_KEY = "aIV2oC0wcryDBO6KZoxuBdYB3eHoTx3u";

const QUICK_REACTIONS = ['🥰', '😡', '😭', '💀', '🤯', '🔥'];

const EMOJI_LIST = [
  '😀','😂','🤣','😍','🥰','😘','😎','🤩','😱','😭','😤','🤔',
  '👍','👎','❤️','🔥','💯','🎉','🙌','👏','🤝','💪','🫶','✨',
  '😴','🤯','🥳','😈','👻','💀','🤡','🙈','🙉','🙊','🐱','💫',
  '🍕','🍔','🍜','🍣','🍺','🎮','🎬','🎵','⚽','🏀','🎯','🚀'
];

const chatContainer = document.createElement('div');
chatContainer.id = 'party-chat-container';
chatContainer.style.display = 'none'; 
chatContainer.innerHTML = `
  <div id="chat-header">
    <span>Party Chat</span>
    <div style="display:flex; align-items:center; gap:8px;">
      <div class="counter-wrapper">
          <span id="party-counter">0 online</span>
          <div id="user-list-tooltip">No one else here</div>
      </div>
      <button id="chat-close-btn">✕</button>
    </div>
  </div>
  <div id="chat-messages"></div>
  <div id="emoji-picker">
    <div id="emoji-grid">${EMOJI_LIST.map(e => `<span class="emoji-item">${e}</span>`).join('')}</div>
  </div>
  <div id="gif-picker">
    <input type="text" id="gif-search" placeholder="Search GIFs...">
    <div id="gif-results"></div>
  </div>
  <div id="reaction-bar">
    ${QUICK_REACTIONS.map(e => `<button class="reaction-btn">${e}</button>`).join('')}
  </div>
  <div id="chat-input-area">
    <input type="text" id="chat-input" placeholder="Say something...">
    <button id="emoji-toggle-btn">😊</button>
    <button id="gif-toggle-btn">GIF</button>
  </div>
`;
document.body.appendChild(chatContainer);

const floatOverlay = document.createElement('div');
floatOverlay.id = 'float-overlay';
document.body.appendChild(floatOverlay);

const toggleBtn = document.createElement('button');
toggleBtn.id = 'chat-toggle-btn';
toggleBtn.innerText = '💬';
toggleBtn.style.display = 'none'; 
document.body.appendChild(toggleBtn);

const style = document.createElement('style');
style.textContent = `
  #party-chat-container {
    position: fixed; right: 0; top: 0; bottom: 0;
    width: 300px; background: rgba(0, 0, 0, 0.95); color: #fff;
    z-index: 9999999; display: flex; flex-direction: column;
    border-left: 2px solid #333; font-family: sans-serif;
    box-shadow: -5px 0 20px rgba(0, 0, 0, 0.5);
  }
  #chat-toggle-btn {
    position: fixed; right: 20px; bottom: 20px;
    z-index: 10000000; width: 50px; height: 50px;
    border-radius: 50%; background: #e50914; color: white;
    border: none; cursor: pointer; font-size: 20px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3); transition: transform 0.2s;
  }
  #chat-toggle-btn:hover { transform: scale(1.05); }
  #chat-header { padding: 15px; background: #e50914; font-weight: bold; display: flex; justify-content: space-between; align-items: center; }
  .counter-wrapper { position: relative; cursor: pointer; }
  #party-counter { font-size: 11px; background: rgba(0,0,0,0.3); padding: 2px 8px; border-radius: 10px; }
  #user-list-tooltip {
    position: absolute; right: 0; top: 25px; background: #222;
    border: 1px solid #444; padding: 10px; border-radius: 5px;
    width: 120px; display: none; font-size: 11px; font-weight: normal;
    z-index: 10000001; box-shadow: 0 4px 10px rgba(0,0,0,0.5);
  }
  .counter-wrapper:hover #user-list-tooltip { display: block; }
  #chat-messages { flex: 1; overflow-y: auto; padding: 10px; display: flex; flex-direction: column; gap: 2px; }
  .chat-msg { font-size: 13px; line-height: 1.2; }
  .chat-msg img { max-width: 100%; border-radius: 6px; margin-top: 4px; display: block; }
  .sys-msg { font-size: 11px; color: #888; font-style: italic; text-align: center; margin: 2px 0; }
  
  #reaction-bar {
    display: flex; justify-content: space-around;
    padding: 6px 10px; border-top: 1px solid #222; background: #0a0a0a;
  }
  .reaction-btn {
    background: none; border: none; font-size: 20px; cursor: pointer;
    padding: 2px 4px; border-radius: 6px; transition: transform 0.15s;
  }
  .reaction-btn:hover { transform: scale(1.3); background: #222; }
  
  #chat-input-area {
    padding: 8px 10px; border-top: 1px solid #333; background: #111;
    display: flex; gap: 6px; align-items: center;
  }
  #chat-input { flex: 1; padding: 8px; background: #222; color: #fff; border: none; border-radius: 4px; font-size: 13px; }
  #emoji-toggle-btn, #gif-toggle-btn {
    background: #222; border: none; color: #fff; cursor: pointer;
    border-radius: 4px; padding: 6px 8px; font-size: 13px; font-weight: bold;
  }
  #emoji-toggle-btn:hover, #gif-toggle-btn:hover { background: #333; }
  
  #emoji-picker {
    display: none; background: #111; border-top: 1px solid #333;
    padding: 8px; max-height: 160px; overflow-y: auto;
  }
  #emoji-grid { display: flex; flex-wrap: wrap; gap: 2px; }
  .emoji-item {
    font-size: 20px; cursor: pointer; padding: 4px;
    border-radius: 4px; transition: background 0.1s;
  }
  .emoji-item:hover { background: #333; }
  
  #gif-picker {
    display: none; background: #111; border-top: 1px solid #333;
    padding: 8px; max-height: 200px; overflow-y: auto;
  }
  #gif-search {
    width: 100%; padding: 6px; background: #222; color: #fff;
    border: none; border-radius: 4px; margin-bottom: 8px; font-size: 12px;
  }
  #gif-results { display: flex; flex-wrap: wrap; gap: 4px; }
  .gif-item { width: 80px; height: 60px; object-fit: cover; cursor: pointer; border-radius: 4px; }
  .gif-item:hover { opacity: 0.8; }
  #gif-load-more {
    width: 100%; padding: 6px; margin-top: 6px; background: #222;
    color: #fff; border: none; border-radius: 4px; cursor: pointer; font-size: 12px;
  }
  #gif-load-more:hover { background: #333; }

  #float-overlay {
    position: fixed; top: 0; left: 0; width: 100%; height: 100%;
    pointer-events: none; z-index: 9999998; overflow: hidden;
  }
  .floating-emoji {
    position: absolute; bottom: 10%; font-size: 36px;
    animation: floatUp 3s ease-out forwards;
    pointer-events: none;
  }
  #chat-close-btn {
    background: none; border: none; color: #fff; cursor: pointer;
    font-size: 14px; padding: 2px 6px; border-radius: 4px; opacity: 0.7;
  }
  #chat-close-btn:hover { opacity: 1; background: rgba(255,255,255,0.1); }
  @keyframes floatUp {
    0%   { transform: translateY(0) scale(1); opacity: 1; }
    80%  { opacity: 1; }
    100% { transform: translateY(-90vh) scale(1.4); opacity: 0; }
  }

  body.yt-chat-open #secondary { display: none !important; }
  body.yt-chat-open #primary { margin-right: 300px !important; }
`;
document.head.appendChild(style);

function resizePlayer(enable) {
  if (isYouTube) {
    document.body.classList.toggle('yt-chat-open', enable);
    return;
  }
  let targetElement = null;
  if (isNetflix) {
    targetElement = document.querySelector('.watch-video') || document.querySelector('.NFPlayer');
  } else if (isHBO) {
    targetElement = document.querySelector('[data-testid="playerContainer"]');
  } else {
    const videoEl = document.querySelector('video');
    if (videoEl) targetElement = videoEl.parentElement;
  }
  if (targetElement) {
    targetElement.style.width = enable ? 'calc(100% - 300px)' : '';
    targetElement.style.left = enable ? '0px' : '';
  }
}

function spawnFloatingEmoji(emoji) {
  const el = document.createElement('div');
  el.className = 'floating-emoji';
  el.innerText = emoji;
  const videoEl = document.querySelector('video');
  if (videoEl) {
    const rect = videoEl.getBoundingClientRect();
    el.style.left = (rect.left + Math.random() * (rect.width - 50)) + 'px';
    el.style.bottom = (window.innerHeight - rect.bottom + 10) + 'px';
  } else {
    el.style.left = (20 + Math.random() * (window.innerWidth - 340)) + 'px';
  }
  floatOverlay.appendChild(el);
  setTimeout(() => el.remove(), 3000);
}

toggleBtn.onclick = () => {
  chatContainer.style.display = 'flex';
  toggleBtn.style.display = 'none';
  resizePlayer(true);
};

document.getElementById('chat-close-btn').onclick = () => {
  chatContainer.style.display = 'none';
  toggleBtn.style.display = 'block';
  resizePlayer(false);
};

document.getElementById('emoji-toggle-btn').onclick = () => {
  const picker = document.getElementById('emoji-picker');
  const gifPicker = document.getElementById('gif-picker');
  gifPicker.style.display = 'none';
  picker.style.display = picker.style.display === 'none' ? 'block' : 'none';
};

document.getElementById('gif-toggle-btn').onclick = () => {
  const picker = document.getElementById('gif-picker');
  const emojiPicker = document.getElementById('emoji-picker');
  emojiPicker.style.display = 'none';
  picker.style.display = picker.style.display === 'none' ? 'block' : 'none';
  if (picker.style.display === 'block' && document.getElementById('gif-results').children.length === 0) {
    searchGifs('trending');
  }
};

document.getElementById('emoji-grid').addEventListener('click', (e) => {
  if (e.target.classList.contains('emoji-item')) {
    const emoji = e.target.innerText;
    const input = document.getElementById('chat-input');
    input.value += emoji;
    input.focus();
  }
});

document.getElementById('reaction-bar').addEventListener('click', (e) => {
  if (e.target.classList.contains('reaction-btn') && isJoined) {
    const emoji = e.target.innerText;
    socket.emit('emoji_reaction', { emoji, user: myUsername, room: myRoom });
    spawnFloatingEmoji(emoji);
  }
});

let gifSearchTimeout = null;
document.getElementById('gif-search').addEventListener('input', (e) => {
  clearTimeout(gifSearchTimeout);
  gifSearchTimeout = setTimeout(() => {
    searchGifs(e.target.value || 'trending');
  }, 500);
});

let gifOffset = 0;
let lastGifQuery = 'trending';

function searchGifs(query, append = false) {
  if (!append) { gifOffset = 0; lastGifQuery = query; }
  const isSearch = query !== 'trending';
  const endpoint = isSearch ? 'search' : 'trending';
  const url = `https://api.giphy.com/v1/gifs/${endpoint}?api_key=${GIPHY_KEY}&q=${encodeURIComponent(query)}&limit=24&offset=${gifOffset}&rating=g`;
  fetch(url)
    .then(r => r.json())
    .then(data => {
      if (!data.data) return;
      const results = document.getElementById('gif-results');
      if (!append) results.innerHTML = '';
      data.data.forEach(gif => {
        const img = document.createElement('img');
        img.className = 'gif-item';
        img.src = gif.images.fixed_width_small.url;
        img.dataset.url = gif.images.fixed_width.url;
        img.onclick = () => {
          socket.emit('send_message', { user: myUsername, color: myColor, gif: img.dataset.url });
          document.getElementById('gif-picker').style.display = 'none';
        };
        results.appendChild(img);
      });
      const existing = document.getElementById('gif-load-more');
      if (existing) existing.remove();
      if (data.data.length === 24) {
        const btn = document.createElement('button');
        btn.id = 'gif-load-more';
        btn.innerText = 'Load more';
        btn.onclick = () => { gifOffset += 24; searchGifs(lastGifQuery, true); };
        results.after(btn);
      }
    })
    .catch(() => {
      document.getElementById('gif-results').innerHTML = '<span style="color:#888;font-size:11px;">GIFs unavailable</span>';
    });
}

chrome.storage.local.get(['roomName', 'userName', 'userColor'], (res) => {
  if (res.userName && res.roomName) {
    myUsername = res.userName;
    myColor = res.userColor;
    
    if (sessionStorage.getItem('shouldRejoin') === 'true') {
      sessionStorage.removeItem('shouldRejoin');
      myRoom = res.roomName;
      socket.emit("join", { room: res.roomName, user: myUsername, activate: true });
      isJoined = true;
      toggleBtn.style.display = 'block';
      
      const savedHistory = sessionStorage.getItem('chatHistory');
      if (savedHistory) {
        setTimeout(() => {
          document.getElementById('chat-messages').innerHTML = savedHistory;
          sessionStorage.removeItem('chatHistory');
        }, 100);
      }
      
      if (sessionStorage.getItem('chatWasOpen') === 'true') {
        setTimeout(() => {
          chatContainer.style.display = 'flex';
          resizePlayer(true);
          sessionStorage.removeItem('chatWasOpen');
        }, 100);
      }
      
      if (sessionStorage.getItem('needsSync') === 'true') {
        sessionStorage.removeItem('needsSync');
        setTimeout(() => socket.emit("request_sync", { room: res.roomName }), 3000);
      }
    } else {
      myRoom = res.roomName;
      socket.emit("join", { room: res.roomName, user: myUsername });
    }
  }
});

socket.on('room_stats', (data) => {
  document.getElementById('party-counter').innerText = `${data.count} online`;
  document.getElementById('user-list-tooltip').innerHTML = `<b>In Room:</b><br>${data.users.join('<br>')}`;
});

function addChatMessage(data) {
  if (!isJoined) return;
  const msgList = document.getElementById('chat-messages');
  const div = document.createElement('div');
  if (data.isSystem || !data.user) {
    div.className = 'sys-msg';
    div.innerText = data.text;
  } else if (data.gif) {
    div.className = 'chat-msg';
    div.innerHTML = `<b style="color: ${data.color || '#54b3ff'}">${data.user}:</b><br><img src="${data.gif}">`;
  } else {
    div.className = 'chat-msg';
    div.innerHTML = `<b style="color: ${data.color || '#54b3ff'}">${data.user}:</b> ${data.text}`;
  }
  msgList.appendChild(div);
  msgList.scrollTop = msgList.scrollHeight;
}

function logSyncAction(user, type, time) {
  if (!isJoined) return;
  const timeStr = new Date(time * 1000).toISOString().substr(14, 5);
  let actionText = type === 'play' ? "played at" : (type === 'pause' ? "paused at" : "jumped to");
  addChatMessage({ text: `${user} ${actionText} ${timeStr}`, isSystem: true });
}

const urlObserver = new MutationObserver(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href;
    const pageTitle = document.title || 'a new page';
    socket.emit("change_url", { url: location.href, user: myUsername, title: pageTitle });
    if (isJoined) addChatMessage({ text: `${myUsername} opened "${pageTitle}"`, isSystem: true });
  }
});

urlObserver.observe(document, { subtree: true, childList: true });

setInterval(() => {
  const currentVideo = document.querySelector('video');
  if (currentVideo && currentVideo !== video) {
    video = currentVideo;
    setupVideoListeners();
  }
}, 2000);

function setupVideoListeners() {
  video.onplay = () => { if (!isRemoteChange) { socket.emit("video_event", { type: "play", time: video.currentTime, user: myUsername }); logSyncAction(myUsername, "play", video.currentTime); } };
  video.onpause = () => { if (!isRemoteChange) setTimeout(() => { if (!isRemoteChange) { socket.emit("video_event", { type: "pause", time: video.currentTime, user: myUsername }); logSyncAction(myUsername, "pause", video.currentTime); } }, 200); };
  video.onseeking = () => { if (!isRemoteChange) { socket.emit("video_event", { type: "seek", time: video.currentTime, user: myUsername }); logSyncAction(myUsername, "seek", video.currentTime); } };
}

socket.on("sync_video", (data) => {
  if (!isJoined || !video) return;
  isRemoteChange = true;
  if (Math.abs(video.currentTime - data.time) > 1.5) video.currentTime = data.time;
  if (data.type === "play") video.play();
  else if (data.type === "pause") video.pause();
  logSyncAction(data.user, data.type, data.time);
  setTimeout(() => { isRemoteChange = false; }, 600);
});

socket.on("navigate_to", (data) => {
  if (!isJoined) return;
  addChatMessage({ text: `${data.user} opened "${data.title || 'a new page'}"`, isSystem: true });
  
  const chatMessages = document.getElementById('chat-messages');
  if (chatMessages) {
    const messages = Array.from(chatMessages.children).slice(-200);
    sessionStorage.setItem('chatHistory', messages.map(m => m.outerHTML).join(''));
  }
  sessionStorage.setItem('shouldRejoin', 'true');
  sessionStorage.setItem('chatWasOpen', chatContainer.style.display === 'flex' ? 'true' : 'false');
  sessionStorage.setItem('needsSync', 'true');
  
  setTimeout(() => { location.href = data.url; }, 2000);
});

socket.on('emoji_reaction', (data) => {
  if (!isJoined) return;
  spawnFloatingEmoji(data.emoji);
});

document.getElementById('chat-input').addEventListener('keypress', (e) => {
  if (e.key === 'Enter' && e.target.value.trim() !== "") {
    socket.emit('send_message', { user: myUsername, text: e.target.value, color: myColor });
    e.target.value = "";
    document.getElementById('emoji-picker').style.display = 'none';
  }
});

socket.on('receive_message', (data) => addChatMessage(data));

socket.on('provide_sync', (data) => {
  if (video && isJoined) {
    socket.emit('sync_response', {
      requesterId: data.requester,
      state: { type: video.paused ? 'pause' : 'play', time: video.currentTime, user: myUsername }
    });
  }
});

chrome.runtime.onMessage.addListener((request) => {
  if (request.action === "join_room") {
    myUsername = request.user;
    myColor = request.color;
    myRoom = request.room;
    socket.emit("join", { room: request.room, user: myUsername, activate: true });
    isJoined = true;
    toggleBtn.style.display = 'block';
  }
  
  if (request.action === "force_sync" && video && isJoined) {
    socket.emit("video_event", { 
      type: video.paused ? 'pause' : 'play', 
      time: video.currentTime, 
      user: myUsername 
    });
  }
});

socket.on('disconnect', () => {
  addChatMessage({ text: '⚠️ Disconnected from server...', isSystem: true });
  toggleBtn.style.opacity = '0.4';
});

socket.on('reconnect', () => {
  toggleBtn.style.opacity = '1';
  if (myRoom) {
    socket.emit("join", { room: myRoom, user: myUsername, activate: isJoined });
  }
  addChatMessage({ text: '✅ Reconnected!', isSystem: true });
});