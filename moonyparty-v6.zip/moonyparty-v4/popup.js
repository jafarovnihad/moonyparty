chrome.storage.local.get(['roomName', 'userName', 'userColor'], (res) => {
  if (res.roomName) document.getElementById('roomInput').value = res.roomName;
  if (res.userName) document.getElementById('nameInput').value = res.userName;
  if (res.userColor) document.getElementById('colorInput').value = res.userColor;
  if (res.roomName) document.getElementById('status').innerText = "Last used: " + res.roomName;
});

const saveCurrentData = () => {
  const roomName = document.getElementById('roomInput').value.trim();
  const userName = document.getElementById('nameInput').value.trim();
  const userColor = document.getElementById('colorInput').value;
  chrome.storage.local.set({ roomName, userName, userColor });
};

document.getElementById('roomInput').oninput = saveCurrentData;
document.getElementById('nameInput').oninput = saveCurrentData;
document.getElementById('colorInput').oninput = saveCurrentData;

const doJoin = () => {
  const roomName = document.getElementById('roomInput').value.trim();
  const userName = document.getElementById('nameInput').value.trim() || "Guest";
  const userColor = document.getElementById('colorInput').value;

  if (!roomName) {
    document.getElementById('status').innerText = "Error: Enter a Room!";
    return;
  }

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]) return;
    chrome.tabs.sendMessage(tabs[0].id, {
      action: "join_room",
      room: roomName,
      user: userName,
      color: userColor
    }, (response) => {
      if (chrome.runtime.lastError) {
        document.getElementById('status').innerText = "Error: Refresh the page!";
      } else {
        document.getElementById('status').innerText = "Joined: " + roomName;
      }
    });
  });
};

document.getElementById('joinBtn').onclick = doJoin;

document.getElementById('roomInput').addEventListener('keypress', (e) => {
  if (e.key === 'Enter') doJoin();
});

document.getElementById('syncBtn').onclick = () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, { action: "force_sync" }, () => {
        document.getElementById('status').innerText = "Synced!";
      });
    }
  });
};