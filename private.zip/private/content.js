const SERVER_URL = "https://my-party-server-060k.onrender.com"; 
let socket = io(SERVER_URL);
let video = null;
let isRemoteChange = false;
let myUsername = "Guest";
let myColor = "#54b3ff";

// --- UI INJECTION ---
const chatContainer = document.createElement('div');
chatContainer.id = 'party-chat-container';
chatContainer.style.display = 'none';
chatContainer.innerHTML = `
  <div id="chat-header">Party Chat</div>
  <div id="chat-messages"></div>
  <div id="chat-input-area"><input type="text" id="chat-input" placeholder="Type a message..."></div>
`;
document.body.appendChild(chatContainer);

const toggleBtn = document.createElement('button');
toggleBtn.id = 'chat-toggle-btn';
toggleBtn.innerText = '💬';
document.body.appendChild(toggleBtn);

const style = document.createElement('style');
style.textContent = `
  #party-chat-container { position: fixed; right: 0; top: 0; bottom: 0; width: 300px; background: #000; color: #fff; z-index: 999999; display: flex; flex-direction: column; border-left: 1px solid #333; font-family: sans-serif; }
  #chat-toggle-btn { position: fixed; right: 20px; bottom: 20px; z-index: 1000000; width: 50px; height: 50px; border-radius: 50%; background: #e50914; color: white; border: none; cursor: pointer; box-shadow: 0 4px 10px rgba(0,0,0,0.5); }
  #chat-header { padding: 15px; background: #e50914; font-weight: bold; }
  #chat-messages { flex: 1; overflow-y: auto; padding: 15px; display: flex; flex-direction: column; gap: 8px; }
  #chat-input-area { padding: 10px; border-top: 1px solid #333; }
  #chat-input { width: 100%; padding: 10px; background: #222; color: #fff; border: none; border-radius: 4px; }
  .chat-msg { font-size: 13px; }
  .sys-msg { font-size: 11px; color: #888; font-style: italic; text-align: center; margin: 5px 0; }
  .video-shrunk { width: calc(100% - 300px) !important; }
`;
document.head.appendChild(style);

// --- HELPER: FORMAT TIME ---
const formatTime = (seconds) => {
  const date = new Date(0);
  date.setSeconds(seconds);
  return date.toISOString().substr(11, 8);
};

// --- HELPER: ADD MESSAGE TO UI ---
function addChatMessage(data, isSystem = false) {
  const msgList = document.getElementById('chat-messages');
  const div = document.createElement('div');
  if (isSystem) {
    div.className = 'sys-msg';
    div.innerText = data.text;
  } else {
    div.className = 'chat-msg';
    div.innerHTML = `<b style="color: ${data.color}">${data.user}:</b> ${data.text}`;
  }
  msgList.appendChild(div);
  msgList.scrollTop = msgList.scrollHeight;
}

// --- CORE LOGIC ---
toggleBtn.onclick = () => {
  const isHidden = chatContainer.style.display === 'none';
  chatContainer.style.display = isHidden ? 'flex' : 'none';
  if (video) isHidden ? video.classList.add('video-shrunk') : video.classList.remove('video-shrunk');
};

chrome.storage.local.get(['roomName', 'userName', 'userColor'], (res) => {
  if (res.userName) myUsername = res.userName;
  if (res.userColor) myColor = res.userColor;
  if (res.roomName) socket.emit("join", { room: res.roomName, user: myUsername });
});

setInterval(() => {
  const curr = document.querySelector('video');
  if (curr && curr !== video) { video = curr; setupVideoListeners(); }
}, 2000);

function setupVideoListeners() {
  video.onplay = () => {
    if (isRemoteChange) return;
    socket.emit("video_event", { type: "play", time: video.currentTime, user: myUsername });
  };
  video.onpause = () => {
    if (isRemoteChange) return;
    socket.emit("video_event", { type: "pause", time: video.currentTime, user: myUsername });
  };

  socket.on("sync_video", (data) => {
    isRemoteChange = true;
    if (Math.abs(video.currentTime - data.time) > 1.5) video.currentTime = data.time;
    data.type === "play" ? video.play() : video.pause();
    
    // Add System Message for Play/Pause
    const action = data.type === "play" ? "played" : "paused";
    addChatMessage({ text: `${data.user} ${action} at ${formatTime(data.time)}` }, true);
    
    setTimeout(() => { isRemoteChange = false; }, 600);
  });
}

// --- CHAT LOGIC ---
document.getElementById('chat-input').addEventListener('keypress', (e) => {
  if (e.key === 'Enter' && e.target.value.trim()) {
    socket.emit('send_message', { user: myUsername, text: e.target.value, color: myColor });
    e.target.value = "";
  }
});

socket.on('receive_message', (data) => addChatMessage(data));

socket.on('user_joined', (user) => {
  addChatMessage({ text: `${user} joined the room` }, true);
});

chrome.runtime.onMessage.addListener((req) => {
  if (req.action === "join_room") {
    myUsername = req.user;
    myColor = req.color;
    socket.emit("join", { room: req.room, user: myUsername });
  }
  if (req.action === "force_sync" && video) {
    socket.emit("video_event", { type: "seek", time: video.currentTime, user: myUsername });
  }
});