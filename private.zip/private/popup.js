// 1. INITIALIZE: Load saved info when the popup opens
chrome.storage.local.get(['roomName', 'userName', 'userColor'], (res) => {
  if (res.roomName) document.getElementById('roomInput').value = res.roomName;
  if (res.userName) document.getElementById('nameInput').value = res.userName;
  if (res.userColor) document.getElementById('colorInput').value = res.userColor;
  
  if (res.roomName) {
    document.getElementById('status').innerText = "Last used: " + res.roomName;
  }
});

// 2. JOIN LOGIC: Handles "Join Room" button click
document.getElementById('joinBtn').onclick = () => {
  const roomName = document.getElementById('roomInput').value;
  const userName = document.getElementById('nameInput').value || "Guest";
  const userColor = document.getElementById('colorInput').value;

  if (!roomName) {
    document.getElementById('status').innerText = "Error: Enter a Room Name!";
    return;
  }

  // Find the active tab and send the join message
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, { 
        action: "join_room", 
        room: roomName, 
        user: userName, 
        color: userColor 
      }, (response) => {
        // ERROR HANDLING: If the content script isn't found
        if (chrome.runtime.lastError) {
          document.getElementById('status').innerText = "Error: Refresh the video page!";
          console.error("Content script not detected.");
        } else {
          // SUCCESS: Save to storage and update UI
          chrome.storage.local.set({ roomName, userName, userColor });
          document.getElementById('status').innerText = "Connected as " + userName;
        }
      });
    }
  });
};

// 3. SYNC LOGIC: Handles "Force Sync All" button click
document.getElementById('syncBtn').onclick = () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, { action: "force_sync" }, (response) => {
        if (chrome.runtime.lastError) {
          document.getElementById('status').innerText = "Error: Refresh the page!";
        } else {
          document.getElementById('status').innerText = "Syncing all users...";
        }
      });
    }
  });
};